# Pasta de templates de arquivos do programa builder

> O programa builder utiliza estes templates de arquivos para construir os códigos fontes padronizados.
